module com.example.estremi_assoluti_su_un_intervallo {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.estremi_assoluti_su_un_intervallo to javafx.fxml;
    exports com.example.estremi_assoluti_su_un_intervallo;
}