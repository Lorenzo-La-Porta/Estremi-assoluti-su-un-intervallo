package com.example.estremi_assoluti_su_un_intervallo;
import net.objecthunter.exp4j.Expression;
import net.objecthunter.exp4j.ExpressionBuilder;

public class RisorseMatematiche {
    double estremo_sx;
    double estremo_dx;
    String funzione;

    RisorseMatematiche(double estremo_sx,double estremo_dx,String funzione){
        this.estremo_sx = estremo_sx;
        this.estremo_dx = estremo_dx;
        this.funzione = funzione;
    }

    public static double trovaMassimo_Minimo(){
        double max;
        double min;
        for (int i = this.estremo_sx; i < this.estremo_dx; i += 0.01){

        }
    }
}
