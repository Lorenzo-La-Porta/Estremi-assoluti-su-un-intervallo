package com.example.estremi_assoluti_su_un_intervallo;

import net.objecthunter.exp4j.Expression;
import net.objecthunter.exp4j.ExpressionBuilder;

public class Calcolatore {
    public static void main(String[] args) {
        String espressione = "sin(x) + x^2";
        Expression e = new ExpressionBuilder(espressione)
                .variable("x")
                .build();
        e.setVariable("x", 3);
        double risultato = e.evaluate();
        System.out.println("Risultato: " + risultato);
    }
}
